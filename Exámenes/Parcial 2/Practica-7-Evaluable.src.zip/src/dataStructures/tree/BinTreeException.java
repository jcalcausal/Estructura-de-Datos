package dataStructures.tree;

@SuppressWarnings("serial")
public class BinTreeException extends RuntimeException {

    public BinTreeException(String msg) {
        super(msg);
    }
}
